import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-good-samaritan',
  templateUrl: './good-samaritan.component.html',
  styleUrls: ['./good-samaritan.component.css']
})
export class GoodSamaritanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
