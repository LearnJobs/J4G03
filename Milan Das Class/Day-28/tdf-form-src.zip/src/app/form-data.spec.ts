import { FormData } from './form-data';

describe('FormData', () => {
  it('should create an instance', () => {
    expect(new FormData()).toBeTruthy();
  });
});
